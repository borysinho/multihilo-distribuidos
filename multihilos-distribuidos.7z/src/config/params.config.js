let params = {
  randomMaxPagoTotal: 10, //Si sale 10 [1..10] se realiza el pago total de la deuda
  tiempoPostAtencion: 1000,
  cantidadHilos: 2,
};

export default { params };
